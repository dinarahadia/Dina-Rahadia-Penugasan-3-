<?php

$databaseHost = 'localhost';
$databaseName = 'polidinafix';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect(
    $databaseHost,
    $databaseUsername,
    $databasePassword,
    $databaseName
);

?>